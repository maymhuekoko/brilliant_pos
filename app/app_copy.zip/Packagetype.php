<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Packagetype extends Model
{
    protected $fillable = ['name'];
}
