

@extends('../frontend/master')
@section('title', 'Home')
@section('content')



    <!-- ============================================-->
    <!-- <section> begin ============================-->
    <section class="pb-6" id="about">
 {{-- <span>#4568DC</span> --}}
      <div class="container">
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                  <div class="carousel-item active">
        <div class="row flex-center">

          <div class="col-lg-6 col-md-5 order-md-1">

               <img class="img-fluid" src="{{asset('frontend/assets/img/pic1.jpg')}}" alt=""/>

              <!-- <div id="carouselExampleIndicators" class="carousel slide col-lg-6 col-md-5 order-md-1" data-ride="carousel">
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img class="d-block w-100 img-fluid" src="{{asset('frontend/assets/img/pic1.jpg')}}" alt="First slide">
                  </div>
                  <div class="carousel-item">
                    <img class="d-block w-100 img-fluid" src="{{asset('frontend/assets/img/pic2.jpg')}}" alt="Second slide">
                  </div>
                  <div class="carousel-item">
                    <img class="d-block w-100 img-fluid" src="{{asset('frontend/assets/img/pic1.jpg')}}" alt="Third slide">
                  </div>
                </div>
              </div> -->

          </div>
          <div class="col-md-7 col-lg-6 mt-5 text-md-start">

            <h5 class="fw-medium"><span style="background-color:#ae17db;color:#fff; " class="py-1 mb-2"> &nbsp;&nbsp; မိတ်ဆက် &nbsp;&nbsp;</span></h5>

            <p class="mt-2 mb-4" style="font-style:italic;color:black;text-indent :5em;">



HS Cargo သည် Hlwan Shwe La Min   Trading and Logistics  Company ၏ လုပ်ငန်းခွဲ တခုဖြစ်ပါသည် …

လွှမ်းရွှေလမင်း ကုမ္ပဏီ ဟာ  နိုင်ငံတကာ ကုန်ပစ္စည်းများ အား ယိုးဒယား နိုင်ငံ ဘန်ကောက် Laem Chabang ဆိပ်ကမ်း မှ  ပေ ၄၀  ကွန်တိန်နာများ ပစ္စည်း များ အား မြန်မာပြည် သို့ Transit  Custom Clearances ပြုလုပ်ပေးခြင်း သယ်ယူပို့ဆောင်ခြင်း ဝန်ဆောင် မှု ပေးနေသော ကုမ္ပဏီဖြစ်ပါသည် ….

Trading အနေနှင့် ယိုးဒယား နိုင်ငံထုတ် ကြွေပြား .. ကျောက်ပြား ( Smart board ) များ အား တင်သွင်း ခြင်း ရောင်းချခြင်း ၂၂ ဘီး တွဲကားများဖြင့် မြန်မာပြည် အနှံ့ ပို့ဆောင်ပေးခြင်း … ဂျပန်နိုင်ငံ မှ လုပ်ငန်းသုံးယဉ် အပိုပစ္စည်းများ တင်သွင်းရောင်းချခြင်း လုပ်ငန်းများ လုပ်ကိုင်နေသော ကုမ္ပဏီ ဖြစ်ပါသည် .


<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


HS cargo လုပ်ငန်း အား ထပ်မံ အကောင်ထည်ဖော် ရခြင်းသည် ကုမ္ပဏီသည် Cargo လုပ်ငန်း အတွက် ဂိုထောင် များ ယိုးဒယား နိုင်ငံ နှင့် မြန်မာနိုင်ငံ တွင် ကုန်ကား များ အခြေခံ အဆောက်အအုံ ကောင်းများ ရှိပီး ဖြစ်သောကြောင့် မိတ်ဆွေများ နှင့် ကုန်သည် များ အား  အဆင်ပြေလွယ်ကူ စွာ ကုန်ပစ္စည်း သယ်ယူပို့ဆောင် ရောင်းချ နိုင်စေရန် - ယိုးဒယား နိုင်ံငံတွင်းရှိ မြန်မာနိုင်ငံသားများ အား အလုပ်ကိုင် များပိုမို ပေးနိုင်ရန် …. အလုပ်ကိုင် အခွင့်လမ်း များ ပိုမိုရရှိရန် ရည်ရွယ်၍ ထပ်မံ လုပ်ကိုင်ရခြင်းဖြစ်ပါသည် …

မိတ်ဟောင်း မိတ်သစ်များအား ဖိတ်ခေါ်ပြီး ကျွန်တော် တို့ နှင့် လက်တွဲ၍ မိတ်ဆွေများ အကျိုးမြတ် ဖြစ်ထွန်းကြပါစေကြောင်း …..

လွှမ်းရွှေလမင်း ကုမ္ပဏီ နှင့် HS cargo မိသားစု တို့မှ ဆုမွန်ကောင်း တောင်းအပ်ပါသည် ခင်ဗျာ …… 🙏🏻🙏🏻




            </p>
            {{-- <a class="btn-grad hover" href="#">Get Started </a> --}}
                  </div>
              </div>
            </div>

            {{-- <div class="carousel-item">
                    <img class="" src="{{asset('frontend/assets/img/pic2.jpg')}}" alt="Second slide" width="1108" height="538">
           </div> --}}
           <div class="carousel-item">
            <img class="" src="{{asset('frontend/assets/img/hspic2.jpg')}}" alt="Second slide" width="1108" height="538">

           </div>

          </div>
        </div>
      </div>
      <!-- end of .container-->


    </section>
    <!-- <section> close ============================-->
    <!-- ============================================-->




    <!-- ============================================-->
    <!-- <section> begin ============================-->
    <section class="py-4">

      <div class="container">
        <div class="card py-5 border-0 shadow-sm">
          <div class="card-body">
            <div class="row">
              <div class="col-4">
                <div class="border-end d-flex justify-content-md-center">
                  <div class="mx-2 mx-md-0 me-md-5">
                    <div class="badge badge-circle bg-soft-danger">
                      <svg class="bi bi-person-fill" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#F53838" viewBox="0 0 16 16">
                        <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"></path>
                      </svg>
                    </div>
                  </div>
                  <div>
                    <p class="fw-bolder text-1000 mb-0">90+ </p>
                    <p class="mb-0">Users </p>
                  </div>
                </div>
              </div>
              <div class="col-4">
                <div class="border-end d-flex justify-content-md-center">
                  <div class="mx-2 mx-md-0 me-md-5">
                    <div class="badge badge-circle bg-soft-danger">
                      <svg class="bi bi-geo-alt-fill" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#F53838" viewBox="0 0 16 16">
                        <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"></path>
                      </svg>
                    </div>
                  </div>
                  <div>
                    <p class="fw-bolder text-1000 mb-0">30+ </p>
                    <p class="mb-0">Users </p>
                  </div>
                </div>
              </div>
              <div class="col-4">
                <div class="d-flex justify-content-md-center">
                  <div class="mx-2 mx-md-0 me-md-5">
                    <div class="badge badge-circle bg-soft-danger">
                      <svg class="bi bi-hdd-stack-fill" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#F53838" viewBox="0 0 16 16">
                        <path d="M2 9a2 2 0 0 0-2 2v1a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-1a2 2 0 0 0-2-2H2zm.5 3a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1zm2 0a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1zM2 2a2 2 0 0 0-2 2v1a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2zm.5 3a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1zm2 0a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1z"></path>
                      </svg>
                    </div>
                  </div>
                  <div>
                    <p class="fw-bolder text-1000 mb-0">50+ </p>
                    <p class="mb-0">Users </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end of .container-->

    </section>
    <!-- <section> close ============================-->
    <!-- ============================================-->




    <!-- ============================================-->

     <!-- <section> begin ============================-->
      <section class="pt-4 pt-md-6" id="features">

        <div class="container">

            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                      <div class="carousel-inner">
                        <div class="carousel-item active">
          <div class="row">
            <div class="col-md-5 col-lg-7 text-lg-center"><img class="img-fluid mb-5 mb-md-0" src="{{asset('frontend/assets/img/pic2.jpg')}}" alt=""/></div>
            <div class="col-md-7 col-lg-5 text-center text-md-start">
              <h4 class="" style="color: #ae17db"><u>Rules and Regulation fot HS Cargo Service</u></h4>
              <div class="d-flex mt-2">
                <i class="bluecolor fas fa-check"></i></i><p class="ms-2  ppp">I guarantee that I am the owner of the goods that will be transported.</p>
              </div>
              <div class="d-flex mt-1">
                <i class="bluecolor fas fa-check"></i><p class="ms-2  ppp ">I agree as a customer or recipient that HS cargo is not concerned with any illegal or unlawful goods whatsoever.</p>
              </div>
              <div class="d-flex mt-1">
                <i class="bluecolor fas fa-check"></i><p class="ms-2  ppp">HS Cargo will not be responsible for the consequences of goods that are successfully received and signed by customer.</p>
              </div>
              <div class="d-flex mt-1">
                <i class="bluecolor fas fa-check"></i><p class="ms-2  ppp">If there is any issue on the goods that didn't pay insurance fee, HS cargo will only compansate 10 times of the delivery fee.
                    &nbsp;&nbsp;&nbsp;<a class="seemore" style="color:#1e0c24;" aria-expanded="false" aria-controls="collapseExample" data-toggle="collapse" data-target="#collapseExample" onclick="btnhide()">see more....</a>
                </p>
              </div>
              {{-- <button class="button design seemore" aria-expanded="false" aria-controls="collapseExample" data-toggle="collapse" data-target="#collapseExample" onclick="btnhide()"><span>See Detail </span></button> --}}
              <button class="button design seemore" aria-expanded="false" aria-controls="collapseExample" data-toggle="modal"
              data-target="#imgModal"><span>See Document</span></button>
              <div class="collapse" id="collapseExample">
                  <div class="d-flex mt-1">
                    <i class="bluecolor fas fa-check"></i><p class="ms-2 ppp">Insurance fee is to provide a compensation for the loss or damage of expensive and valueable goods according to the original worth of the goods.Insurance fee is charged 5% of the good's price.</p>
                  </div>
                  <div class="d-flex mt-1">
                    <i class="bluecolor fas fa-check"></i><p class="ms-2  ppp">I completely agree with the above terms and conditions as a customer or recipient.</p>
                  </div>
                  <button class="button design" aria-expanded="false" aria-controls="collapseExample" data-toggle="modal"
                   data-target="#imgModal"><span>See Document</span></button>
                  <a href="#features" class="previous design1" onclick="close_coll()">&laquo; Previous</a>

              </div>
            </div>
          </div>

          {{-- slide --}}
                      </div>

                        {{-- @foreach ($news as $n)
                        <div class="carousel-item">
                        <div class="row">
                          <div class="col-md-5 col-lg-7 text-lg-center"><img class="img-fluid mb-5 mb-md-0" src="public/images/{{$n->image}}" alt=""/></div>
                          <div class="col-md-7 col-lg-5 text-center text-md-start">
                            <h4 class="" style="color: #ae17db"><u>{{$n->title}}</u></h4>
                            <div class="d-flex mt-2">
                              <i class="bluecolor fas fa-check"></i></i><p class="ms-2  ppp">{{$n->description}}</p>
                            </div>

                          </div>
                        </div>
                        </div>
                        @endforeach --}}

                  </div>
              </div>
        </div>


        <div class="modal fade"
        id="imgModal"
        tabindex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true">
       <div class="modal-dialog"
            role="document">
           <div class="modal-content">
               <!-- Modal heading -->
               {{-- <div class="modal-header">
                   <h5 class="modal-title"
                       id="exampleModalLabel">
                     Rule and Regulations for HS Cargo's Customer
                 </h5>
                   <button type="button"
                           class="close"
                           data-dismiss="modal"
                           aria-label="Close">
                       <span aria-hidden="true">
                         ×
                     </span>
                  </button>
              </div> --}}

              <!-- Modal body with image -->
              <div class="modal-body">
                  <img src="{{asset('frontend/assets/img/pp2.jpg')}}" width="470"/>
              </div>
          </div>
      </div>
  </div>
        <!-- end of .container-->

      </section>
            <!-- end of .container-->

          </section>

    <!-- <section> close ============================-->
    <!-- ============================================-->




    <!-- ============================================-->

   <!-- <section> begin ============================-->
    <section class="bg-100 py-7" id="plan">

        <div class="container-lg">
          <div class="row justify-content-center">
            <div class="col-md-8 col-lg-5 text-center mb-3">
              <h2>Our Delivery Pricing</h2>
            </div>
          </div>
          <div class="row h-100 justify-content-center">
              <div class="col-md-3 pt-4">
                  <div class="card" style="max-width: 18rem;">
                      {{-- <div class="card-header text-center header">BKK - YGN</div> --}}

                      <div class="card-body card_color">
                              <h4 class="text-center" style="color:#fff">BKK - YGN</h4>
                          {{-- @foreach ($packages as $p)
                            @foreach ($packageKg as $pp)
                              @if ($p->id == $pp->package_id)
                                  @if (($p->from_city_name == 'BKK' && $p->to_city_name == 'YGN') || ($p->from_city_name == 'YGN' && $p->to_city_name == 'BKK'))
                                  <div class="row mt-2">
                                      <div class="col-md-6"><p class="p_card">{{$pp->min_kg}} - {{$pp->max_kg}} KG</p></div>
                                      <div class="col-md-6"><p class="p_card">{{$pp->per_kg_price}} {{$pp->currency}}</p></div>
                                  </div>
                                  @endif
                              @endif
                            @endforeach
                          @endforeach --}}
                       </div>
                    </div>
              </div>
              <div class="col-md-3 pt-4">
                  <div class="card" style="max-width: 18rem;">
                      {{-- <div class="card-header text-center header">BKK - YGN</div> --}}

                      <div class="card-body card_color">
                              <h4 class="text-center" style="color:#fff">BKK - MDY</h4>
                          {{-- @foreach ($packages as $p)
                            @foreach ($packageKg as $pp)
                              @if ($p->id == $pp->package_id)
                                  @if (($p->from_city_name == 'BKK' && $p->to_city_name == 'MDY') || ($p->from_city_name == 'MDY' && $p->to_city_name == 'BKK'))
                                  <div class="row mt-2">
                                      <div class="col-md-6"><p class="p_card">{{$pp->min_kg}} - {{$pp->max_kg}} KG</p></div>
                                      <div class="col-md-6"><p class="p_card">{{$pp->per_kg_price}} {{$pp->currency}}</p></div>
                                  </div>
                                  @endif
                              @endif
                            @endforeach
                          @endforeach --}}
                       </div>
                    </div>
              </div>
              <div class="col-md-3 pt-4">
                  <div class="card" style="max-width: 18rem;">
                      {{-- <div class="card-header text-center header">BKK - YGN</div> --}}

                      <div class="card-body card_color">
                              <h4 class="text-center" style="color:#fff">Measot - YGN</h4>
                          {{-- @foreach ($packages as $p)
                            @foreach ($packageKg as $pp)
                              @if ($p->id == $pp->package_id)
                                  @if (($p->from_city_name == 'MAESOT' && $p->to_city_name == 'YGN') || ($p->from_city_name == 'YGN' && $p->to_city_name == 'MAESOT'))
                                  <div class="row mt-2">
                                      <div class="col-md-6"><p class="p_card">{{$pp->min_kg}} - {{$pp->max_kg}} KG</p></div>
                                      <div class="col-md-6"><p class="p_card">{{$pp->per_kg_price}} {{$pp->currency}}</p></div>
                                  </div>
                                  @endif
                              @endif
                            @endforeach
                          @endforeach --}}
                       </div>
                    </div>
              </div>
              <div class="col-md-3 pt-4">
                  <div class="card" style="max-width: 18rem;">
                      {{-- <div class="card-header text-center header">BKK - YGN</div> --}}

                      <div class="card-body card_color">
                              <h4 class="text-center" style="color:#fff">Maesot - MDY</h4>
                          {{-- @foreach ($packages as $p)
                            @foreach ($packageKg as $pp)
                              @if ($p->id == $pp->package_id)
                                  @if (($p->from_city_name == 'MAESOT' && $p->to_city_name == 'MDY') || ($p->from_city_name == 'MDY' && $p->to_city_name == 'MAESOT'))
                                  <div class="row mt-2">
                                      <div class="col-md-6"><p class="p_card">{{$pp->min_kg}} - {{$pp->max_kg}} KG</p></div>
                                      <div class="col-md-6"><p class="p_card">{{$pp->per_kg_price}} {{$pp->currency}}</p></div>
                                  </div>
                                  @endif
                              @endif
                            @endforeach
                          @endforeach --}}

                       </div>
                    </div>
              </div>

          </div>
        </div>
        <!-- end of .container-->

      </section>
      <!-- <section> close ============================-->

    <!-- ============================================-->




    <!-- ============================================-->
    <!-- <section> begin ============================-->
    <section class="bg-100 py-7 text-center" id="test">

      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-8 col-lg-5">
            <h2>Our Delivery Network</h2>
          </div>
          <div class="pt-5">
            <div class="row">
                @foreach ($items as $item)
                @if ($item->photo_path != "default.jpg")
                <div class="col-md-3">
                    <div class="card mt-5" style="width: 18rem;">
                      <img class="card-img-top" src="frontend/assets/img/{{$item->photo_path}}" alt="Card image cap">
                      <div class="card-body">
                        <h5 class="card-title">Item Name-{{$item->item_name}}</h5>
                        <h6 class="text-left">Item Code-{{$item->item_code}}</h6>
                        <h6 class="card-text">Selling Price-{{$item->selling_price}}</h6>
                      </div>
                  </div>
                  </div>

                @endif

                @endforeach

            </div>
          </div>


        </div>
        </div>

      <!-- end of .container-->

    </section>
    <!-- <section> close ============================-->
    <!-- ============================================-->




    <!-- ============================================-->
    <!-- <section> begin ============================-->
    <section class="py-5 bg-100">

      <div class="container">
        <div class="row justify-content-center">
          <div class="col-6 col-sm-4 col-md-2 mb-2 mb-md-0"><img class="img-fluid" src="{{asset('frontend/assets/img/gallery/netflix.png')}}" alt="" height="50" /></div>
          <div class="col-6 col-sm-4 col-md-2 mb-2 mb-md-0"><img class="img-fluid" src="{{asset('frontend/assets/img/gallery/reddit.png')}}" alt="" height="50" /></div>
          <div class="col-6 col-sm-4 col-md-2 mb-2 mb-md-0"><img class="img-fluid" src="{{asset('frontend/assets/img/gallery/amazon.png')}}" alt="" height="50" /></div>
          <div class="col-6 col-sm-4 col-md-2 mb-2 mb-sm-0"><img class="img-fluid" src="{{asset('frontend/assets/img/gallery/discord.png')}}" alt="" height="50" /></div>
          <div class="col-6 col-sm-4 col-md-2 mb-2 mb-sm-0"><img class="img-fluid" src="{{asset('frontend/assets/img/gallery/spotify.png')}}" alt="" height="50" /></div>
        </div>
      </div>
      <!-- end of .container-->

    </section>
    <!-- <section> close ============================-->
    <!-- ============================================-->




    <!-- ============================================-->
    <!-- <section> begin ============================-->
    <section class="py-7">

      <div class="container">
        <div class="row flex-center">
          <div class="col-md-8 col-lg-5 text-center">
            <h2>Trusted by Thousands of<br />Happy Customer</h2>
            <p>These are the stories of our customers who have joined us with great pleasure when using this crazy feature.</p>
          </div>
        </div>

      </div>
      <!-- end of .container-->

    </section>
    <!-- <section> close ============================-->
    <!-- ============================================-->




    <!-- ============================================-->
    <!-- <section> begin ============================-->

    <!-- <section> close ============================-->
    <!-- ============================================-->




    <!-- ============================================-->
    <!-- <section> begin ============================-->
    <section class="py-7" id="help">

      <div class="container">
        <h4 class="text-center mb-5">Company of &nbsp;&nbsp;&nbsp;<img src="{{asset('frontend/assets/img/logo20.jpg')}}" alt="" width="200"></h4>
        <div class="row">

          <div class="col-6 col-sm-4 col-lg-3 mb-3">
            <h5 class="lh-lg"> <span style="background-color:rgb(247, 132, 38);color:#fff "> &nbsp;&nbsp;&nbsp; Bangkok &nbsp;&nbsp;&nbsp;</span></h5>
            <ul class="list-unstyled mb-md-4 mb-lg-0">
              {{-- @foreach ($contacts as $c)
              @if ($c->location == "BKK")
              <li class="lh-lg"><a class="text-900 text-decoration-none" href="#!"><span style="font-style:italic;color:hsl(325, 64%, 50%)">{{$c->address}}</span></a></li>

              @endif

              @endforeach
              @foreach ($contacts as $c)
              @if ($c->location == "BKK")

              <li class="lh-lg"><a class="text-900 text-decoration-none" href="#!"><span style="font-style:italic;color:hsl(325, 64%, 50%)">++{{$c->phone_number}}</span></a></li>
              @endif

              @endforeach --}}

            </ul>
          </div>
          <div class="col-6 col-sm-4 col-lg-3 mb-3">
            <h5 class="lh-lg"><span style="background-color:rgb(247, 132, 38);color:#fff "> &nbsp;&nbsp;&nbsp; Maesot &nbsp;&nbsp;&nbsp;</span></h5>
            <ul class="list-unstyled mb-md-4 mb-lg-0">
              {{-- @foreach ($contacts as $c)
              @if ($c->location == "MAESOT")
              <li class="lh-lg"><a class="text-900 text-decoration-none" href="#!"><span style="font-style:italic;color:hsl(325, 64%, 50%)">{{$c->address}}</span></a></li>

              @endif

              @endforeach
              @foreach ($contacts as $c)
              @if ($c->location == "MAESOT")

              <li class="lh-lg"><a class="text-900 text-decoration-none" href="#!"><span style="font-style:italic;color:hsl(325, 64%, 50%)">++{{$c->phone_number}}</span></a></li>
              @endif

              @endforeach --}}
            </ul>
          </div>
          <div class="col-12 col-sm-4 col-lg-3 mb-3 ps-xxl-7 ps-xl-5">
            <h5 class="lh-lg"><span style="background-color:rgb(247, 132, 38);color:#fff "> &nbsp;&nbsp;&nbsp; Yangon &nbsp;&nbsp;&nbsp;</span> </h5>
            <ul class="list-unstyled mb-md-4 mb-lg-0">
              {{-- @foreach ($contacts as $c)
              @if ($c->location == "YGN")
              <li class="lh-lg"><a class="text-900 text-decoration-none" href="#!"><span style="font-style:italic;color:hsl(325, 64%, 50%)">{{$c->address}}</span></a></li>

              @endif

              @endforeach
              @foreach ($contacts as $c)
              @if ($c->location == "YGN")

              <li class="lh-lg"><a class="text-900 text-decoration-none" href="#!"><span style="font-style:italic;color:hsl(325, 64%, 50%)">++{{$c->phone_number}}</span></a></li>
              @endif

              @endforeach --}}
            </ul>
          </div>
          <div class="col-12 col-sm-4 col-lg-3 mb-3 ps-xxl-7 ps-xl-5">
            <h5 class="lh-lg"><span style="background-color:rgb(247, 132, 38);color:#fff "> &nbsp;&nbsp;&nbsp; Myawaddy &nbsp;&nbsp;&nbsp;</span> </h5>
            <ul class="list-unstyled mb-md-4 mb-lg-0">
              {{-- @foreach ($contacts as $c)
              @if ($c->location == "MYAWADY")
              <li class="lh-lg"><a class="text-900 text-decoration-none" href="#!"><span style="font-style:italic;color:hsl(325, 64%, 50%)">{{$c->address}}</span></a></li>

              @endif

              @endforeach
              @foreach ($contacts as $c)
              @if ($c->location == "MYAWADY")

              <li class="lh-lg"><a class="text-900 text-decoration-none" href="#!"><span style="font-style:italic;color:hsl(325, 64%, 50%)">++{{$c->phone_number}}</span></a></li>
              @endif

              @endforeach --}}
            </ul>
          </div>

        </div>
      </div>
      <!-- end of .container-->

    </section>
    <!-- <section> close ============================-->
    <!-- ============================================-->

@endsection


@section('js')
<script>
    function btnhide(){
      $('.seemore').hide();
    }
    function close_coll(){
        $('.collapse').collapse('hide');
        // alert('hellolllll');
        $('.seemore').show();
    }
</script>
@endsection

{{-- maymyatmoe --}}

